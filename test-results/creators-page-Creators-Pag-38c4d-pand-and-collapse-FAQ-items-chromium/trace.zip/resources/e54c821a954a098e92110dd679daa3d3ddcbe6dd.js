(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0mzwwn9._.css","static/chunks/node_modules_0_6vz4s._.js","static/chunks/lib_auth_auth-context_tsx_0h3ktws._.js"],
    source: "dynamic"
});
