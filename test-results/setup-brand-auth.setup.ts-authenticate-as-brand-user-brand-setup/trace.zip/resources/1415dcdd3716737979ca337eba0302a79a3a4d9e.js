(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0mxry0u._.js","static/chunks/node_modules_lodash_0g-z0w7._.js","static/chunks/node_modules_recharts_es6_0hy63z0._.js","static/chunks/node_modules_0-bap4x._.js","static/chunks/app_styles_components_dashboard-stats_0gpl_z3.css"],
    source: "dynamic"
});
