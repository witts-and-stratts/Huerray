(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0_r5.zi._.js","static/chunks/node_modules_0kgwfzz._.js"],
    source: "dynamic"
});
