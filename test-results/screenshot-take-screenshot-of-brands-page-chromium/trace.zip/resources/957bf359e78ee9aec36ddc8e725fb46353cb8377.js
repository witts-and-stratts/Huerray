(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0dl.xbw._.js","static/chunks/node_modules_next_0zpwf7z._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_axios_lib_0qhimsy._.js","static/chunks/node_modules_framer-motion_dist_es_03co3hq._.js","static/chunks/node_modules_motion-dom_dist_es_0wgax3s._.js","static/chunks/node_modules_0_a1-i7._.js","static/chunks/node_modules_@splidejs_react-splide_dist_css_splide_min_0pzttep.css"],
    source: "dynamic"
});
