(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0fsjvvs._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_next_0oy.yw1._.js","static/chunks/node_modules_motion-dom_dist_es_0smvfil._.js","static/chunks/node_modules_framer-motion_dist_es_129u8xh._.js","static/chunks/node_modules_axios_lib_0qhimsy._.js","static/chunks/node_modules_0xnpjt_._.js","static/chunks/node_modules_@splidejs_react-splide_dist_css_splide_min_0pzttep.css"],
    source: "dynamic"
});
