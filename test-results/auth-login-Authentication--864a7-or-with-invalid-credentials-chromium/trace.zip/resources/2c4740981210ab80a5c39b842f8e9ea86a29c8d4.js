(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_11wvw~x._.js","static/chunks/_0im1nha._.js","static/chunks/app_styles_dashboard-globals_0hpha48.css"],
    source: "dynamic"
});
